from addict import Dict

config = Dict(
    enabled=True)
config.freeze()
