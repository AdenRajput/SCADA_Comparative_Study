from .model import Model
from .doppelganger_torch_model import DoppelGANgerTorchModel

__all__ = ['Model', 'DoppelGANgerTorchModel']
