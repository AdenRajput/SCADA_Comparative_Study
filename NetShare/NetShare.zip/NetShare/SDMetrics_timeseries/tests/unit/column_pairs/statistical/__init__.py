"""Unit tests for the column pairs statistical metrics."""
