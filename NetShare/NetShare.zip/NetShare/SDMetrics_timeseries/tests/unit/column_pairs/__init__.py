"""Unit tests for the column pairs module."""
