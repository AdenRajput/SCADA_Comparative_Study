"""Unit tests for the single column module."""
