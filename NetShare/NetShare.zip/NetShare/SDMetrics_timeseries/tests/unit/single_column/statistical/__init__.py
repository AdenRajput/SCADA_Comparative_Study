"""Unit tests for the statistical single column metrics."""
