"""SDMetrics integration testing for the reports module."""
