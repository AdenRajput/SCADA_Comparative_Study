"""SDMetrics integration testing for the single-table reports module."""
