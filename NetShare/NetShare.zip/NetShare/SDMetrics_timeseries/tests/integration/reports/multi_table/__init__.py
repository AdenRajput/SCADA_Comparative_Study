"""SDMetrics integration testing for the multi-table reports module."""
