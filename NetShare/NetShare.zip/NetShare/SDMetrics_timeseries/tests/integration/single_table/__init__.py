"""SDMetrics integration testing for the single_table module."""
