"""SDMetrics integration testing for the multi_table module."""
