"""SDMetrics integration testing for the timeseries module."""
