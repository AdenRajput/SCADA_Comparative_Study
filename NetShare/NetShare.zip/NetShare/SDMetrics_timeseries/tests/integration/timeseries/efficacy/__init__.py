"""SDMetrics integration testing for the timeseries efficacy module."""
