"""SDMetrics integration testing for the column_pairs module."""
