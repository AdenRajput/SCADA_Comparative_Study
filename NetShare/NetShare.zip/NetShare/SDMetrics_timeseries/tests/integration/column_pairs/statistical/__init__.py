"""SDMetrics integration testing for the column_pairs statistical module."""
