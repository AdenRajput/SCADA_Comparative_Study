import netshare.ray as ray
from netshare import Generator

if __name__ == '__main__':
    # Disable Ray if using single machine
    ray.config.enabled = False
    ray.init(address="auto")

    # Load the dataset and train
    generator = Generator(config="config_example_netflow_nodp_daf.json")
    generator.train(work_folder="../../results/my_data")

    # Generate synthetic data
    generator.generate(work_folder="../../results/my_data")

    # Visualize results
    generator.visualize(work_folder="../../results/my_data")

    ray.shutdown()
